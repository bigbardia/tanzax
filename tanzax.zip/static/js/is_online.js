fetch("/ping")


setInterval( () => {
    fetch("/ping")
},15 * 1000)